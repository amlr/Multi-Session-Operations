class casevac {
	file = "support\modules\rmm_casevac";
	class functions {
		class call {};
		class help {};
		class onload {};
	};
};