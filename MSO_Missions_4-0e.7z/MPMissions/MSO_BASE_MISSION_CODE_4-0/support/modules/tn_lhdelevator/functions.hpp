class lhdelev {
	file = "support\modules\tn_lhdelevator";
	class functions {
		class moveElevatorDown {};
		class moveElevatorUp {};
		class stopElevator {};
	};
};