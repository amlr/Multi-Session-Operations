[3:56:45 PM] Rommel: hmmm
[3:56:50 PM] Rommel: The old teamstatus idea
[3:56:53 PM] Rommel: Oooo this could be interesting
[3:56:58 PM] Rommel: Old teamstatus menu
[3:57:01 PM] Rommel: Or similar
[3:57:06 PM] Rommel: But instead of spawning where you were
[3:57:11 PM] Rommel: You spawn on them
[3:57:20 PM] Rommel: Ie teamleaders setup teams at base
[3:57:27 PM] Rommel: and people can join their team before they leave
[3:57:30 PM] Ryan: but then you could die in firefight - spawn on them.. get into firefight - thats not the mso
[3:57:32 PM] Rommel: Once their out of base people can't join
[3:57:40 PM] Ryan: spawn on an object - then put these objects at different PB's etc
[3:57:43 PM] Rommel: but from then on people join on and thats the team position
[3:57:51 PM] Rommel: no no
[3:57:54 PM] Rommel: no spawn on them
[3:57:58 PM | Edited 3:58:01 PM] Rommel: once you die you leave the team
[3:58:07 PM] Ryan: dont get it
[3:58:07 PM] Rommel: let me explain
[3:58:14 PM] Rommel: 

3 players, A, B, C
[3:58:16 PM] Ryan: and read my chart board idea
[3:58:17 PM] Rommel: A is a teamleader
[3:58:32 PM] Rommel: A kits up at base by himself, sets up a team and heads out
[3:58:38 PM] Rommel: 4hrs of patrolling later, he logs out at 0102
[3:58:46 PM] Rommel: B and C then join
[3:58:53 PM] Rommel: uh
[3:59:01 PM] Rommel: correction, B and C joined his team before he left.
[3:59:05 PM] Rommel: But then quit.
[3:59:11 PM] Rommel: B and C then rejoin.
[3:59:20 PM] Rommel: And they spawn at 0102
[3:59:26 PM] Rommel: With the gear they had prior
[3:59:28 PM] Ryan: right so we dont get people scattered
[3:59:33 PM] Rommel: Right
[3:59:34 PM] Ryan: good idea
[3:59:38 PM] Rommel: Its a way of keeping teams together
[3:59:44 PM] Ryan: rgr
[3:59:49 PM] Rommel: They spawn on the leaders position
[3:59:53 PM] Ryan: less "oh come pick me up"
[3:59:55 PM | Edited 3:59:59 PM] Rommel: as though the team *was* together
[3:59:59 PM] Ryan: rgr
[4:00:05 PM] Rommel: you can't spawn on them
[4:00:09 PM] Rommel: after death
[4:00:19 PM] Rommel: but it simulates as though you were with them the whole time
[4:00:21 PM] Ryan: ok so when you die
[4:00:26 PM] Ryan: you spawn at base
[4:00:28 PM] Rommel: yes
[4:00:43 PM] Ryan: but if objects that were spawnable on - you could spawn at a PB -  closer without the travel time
[4:00:46 PM] Rommel: and the other thing, if you logout more than say... 500m from your teams position
[4:00:50 PM] Rommel: then it assumes you left the team
[4:00:53 PM] Ryan: rgr
[4:01:06 PM] Rommel: so that way you cant join a team
[4:01:10 PM] Ryan: yup :) good idea
[4:01:10 PM] Rommel: run off to other side of map
[4:01:17 PM] Rommel: then appear at your teams position when you rejoin
[4:01:28 PM] Rommel: awesome feature I think :)
[4:01:28 PM] Ryan: ok so you spawn only on the teamleader of that team
[4:01:49 PM] Ryan: meaning we'll have to have only good teamleaders (glenn, anti, me, you, wolfy or floydii)
[4:01:56 PM] Ryan: not tank
[4:01:57 PM] Rommel: No you spawn on the team position, which may or may not be the team leaders position
[4:02:04 PM] Ryan: hmm okay
[4:02:07 PM] Rommel: Ie
[4:02:09 PM] Rommel: 3 guys could join
[4:02:14 PM] Rommel: All part of A's team
[4:02:17 PM] Rommel: but A is away
[4:02:25 PM] Rommel: they spawn where A was
[4:02:36 PM] Rommel: and then move to 0204
[4:02:41 PM] Rommel: A joins, and logs on at 0204
[4:02:44 PM] Rommel: As though he was with them
[4:02:54 PM] Rommel: Make sense?
[4:03:36 PM] Ryan: rgr
[4:03:39 PM] Rommel: I think I'll make the team menu not a base thing, but a radio option
[4:03:45 PM] Rommel: That way you can leave teams out in the field
[4:03:48 PM] Ryan: make it so
[4:03:49 PM] Rommel: And join teams aswell
[4:04:03 PM] Rommel: Ie I may want to logout but not be part of the team
[4:04:04 PM] Ryan: if they within a certain distance of base or a pb and the team is far far away from that then they spawn there when reconnect
[4:04:13 PM] Ryan: rgr
[4:04:16 PM] Ryan: if you wanna go rambo :P
[4:04:20 PM] Rommel: exactly
[4:04:28 PM] Rommel: its a good idea
[4:04:32 PM] Rommel: its not breaking any simulation really
[4:04:33 PM] Ryan: ability to create teams too
[4:04:34 PM] Ryan: aka recce team
[4:04:42 PM] Rommel: infact its more realistic
[4:05:02 PM] Ryan: rgr
[4:05:35 PM] Ryan: saves all the hassel and makes gaming easier - cos if people have to go - they have to go - in reality they wouldn't but they would be with the team all the time and end up returning to the base they started off at, right
[4:05:37 PM] Rommel: the only thing is, you have to be there when the teams being formed
[4:05:42 PM] Rommel: or you start at base
[4:06:11 PM] Rommel: small price to pay
[4:06:20 PM] Ryan: add that chart board idea too 
[3:51 PM] Ryan: 

<<< I was thinking route chart - like on the chart board
or having seperate cateogories on the chart board
aka the notepad rom - at the front of the takistani base near main enterance
re-name it chart board man :P anyway i was thinking have categories like leadership - you click it - shows the leadership structure and teamleaders/admins/gamemaster can change it - and diff categories etc like resupply times and equipment amount - route charts, where what squad is going, their AO, support units linked to them etcKeeps people informed - WITHOUT filling up the AAR menu
[4:06:31 PM] Ryan: Yeah easy enough Rommel
[4:06:36 PM] Ryan: and good idea :P
[4:06:40 PM] Ryan: never even considered that
[4:06:58 PM] Rommel: haha it was your idea :D
[4:07:05 PM] Rommel: [4:06 PM] Ryan: 

<<< shows the leadership structure and teamleaders/admins/gamemaster can change it
[4:07:10 PM] Rommel: thats what I thought you meant
[4:07:12 PM] Ryan: meh :D cant memba
[4:07:24 PM] Rommel: sort of ... derailed from that idea
[4:07:25 PM] Ryan: yeah youre right
[4:07:26 PM] Rommel: but still :P
[4:07:33 PM] Ryan: leadership structure has to be changed when peopel d/c anyway :P
[4:07:34 PM] Ryan: clever
[4:07:38 PM] Ryan: i wasnt even thinking of that :D
[4:08:03 PM] Ryan: Wolfy this is typical MSO discussion right here