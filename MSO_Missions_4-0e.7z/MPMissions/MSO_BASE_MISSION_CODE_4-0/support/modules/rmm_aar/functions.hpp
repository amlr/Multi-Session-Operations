class aar {
	file = "support\modules\rmm_aar";
	class functions {
		class broadcast {};
		class onload {};
		class submit {};
	};
};