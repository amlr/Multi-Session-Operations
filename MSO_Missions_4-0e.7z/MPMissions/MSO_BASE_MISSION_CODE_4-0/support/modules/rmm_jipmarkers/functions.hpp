class jipmarkers {
	file = "support\modules\rmm_jipmarkers";
	class functions {
		class click {};
		class deletenearest {};
		class onload {};
		class transmit {};
	};
};