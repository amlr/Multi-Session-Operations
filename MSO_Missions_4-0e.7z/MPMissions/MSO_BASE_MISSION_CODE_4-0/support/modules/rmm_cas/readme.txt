Testing:
To test, move the module folder into MSOTesting.Zargabad\modules folder.

Modify the modules.hpp file and enable the module.

Launch using a dedicated server and perform the testing procedure before releasing:
- try calling in CAS of different types
- try attacking targets on runway (gunner will say 'negative' to the attacks but attack anyway)

Questions
- when does the unit leave the squad?

Wolffy - 

Added LDL's AC130 script (Tupolov)