class LDL_gun01
{
	name = "LDL_gun01";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\gun01.ogg, db+3, 1.0};
	titles[]= {}; 
};
		
class LDL_gun02
{
	name = "LDL_gun02";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\gun02.ogg, db+3, 1.0};
	titles[]= {}; 
};
		
class LDL_gun03
{
	name = "LDL_gun03";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\gun03.ogg, db+5, 1.0};
	titles[]= {}; 
};
			
class LDL_reload
{
	name = "LDL_reload";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\reload.ogg, db+5, 1.0};
	titles[]= {}; 
};
	
class LDL_Amb01
{
	name = "LDL_Amb01";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\Amb01.ogg, db+2, 1.0};
	titles[]= {}; 
};
	
class LDL_Amb02
{
	name = "LDL_Amb02";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\Amb02.ogg, db+2, 1.0};
	titles[]= {}; 
};
	
class LDL_Amb03
{
	name = "LDL_Amb03";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\Amb03.ogg, db+2, 1.0};
	titles[]= {}; 
};
		
class LDL_Amb04
{
	name = "LDL_Amb04";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\Amb04.ogg, db+2, 1.0};
	titles[]= {}; 
};
		
class LDL_Amb05
{
	name = "LDL_Amb05";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\Amb05.ogg, db+2, 1.0};
	titles[]= {}; 
};
		
class LDL_Amb06
{
	name = "LDL_Amb06";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\Amb06.ogg, db+2, 1.0};
	titles[]= {}; 
};
		
class LDL_Amb07
{
	name = "LDL_Amb07";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\Amb07.ogg, db+2, 1.0};
	titles[]= {}; 
};
		
class LDL_Amb08
{
	name = "LDL_Amb08";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\Amb08.ogg, db+2, 1.0};
	titles[]= {}; 
};
		
class LDL_Amb09
{
	name = "LDL_Amb09";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\Amb09.ogg, db+2, 1.0};
	titles[]= {}; 
};
		
class LDL_Amb10
{
	name = "LDL_Amb10";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\Amb10.ogg, db+2, 1.0};
	titles[]= {}; 
};

class LDL_Interior01
{
	name = "LDL_Interior01";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\interiorLoop01.ogg, db+0, 1.0};
	titles[]= {}; 
};

class LDL_Interior02
{
	name = "LDL_Interior02";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\interiorLoop02.ogg, db+0, 1.0};
	titles[]= {}; 
};

class LDL_Interior03
{
	name = "LDL_Interior03";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\interiorLoop03.ogg, db+0, 1.0};
	titles[]= {}; 
};

class LDL_Interior
{
	name = "LDL_Interior";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\Interior.ogg, db+0, 1.0};
	titles[]= {}; 
};

class LDL_beep_short
{
	name = "LDL_beep_short";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\beep_short.ogg, db+0, 1.0};
	titles[]= {}; 
};

class LDL_beep_long
{
	name = "LDL_beep_long";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\beep_long.ogg, db+0, 1.0};
	titles[]= {}; 
};

class LDL_empty
{
	name = "LDL_empty";
	sound[] = {\support\modules\rmm_cas\LDL_ac130\Sounds\empty.ogg, db+0, 1.0};
	titles[]= {}; 
};