class LDL_DialogAC130: LDL_DialogParent
{
	idd = 1000;
	movingEnable = true;
	controlsBackground[] = {};
	controls[] = 
	{
		/*Bottom*/Target10,Target9,Target8,Target7,Target6,Target5,Target4,Target3,Target2,Target1,TargetText,indicatorVerBar,indicatorVerFrame,indicatorVerText,indicatorHorText,indicatorHorBar,indicatorHorFrame,West,South,East,North,Range,Cross,Center2,Center,mouseHandler,Info4,Info3,Info2,Info1,Warning,
		/*Middle*/Display,
		/*Top*/Info5
	};
};