class revive {
	file = "support\modules\rmm_revive";
	class functions {
		class init {};
		class conscious {};
		class unconscious {};
		class damage {};
		class heal {};
		class drag {};
		class drop {};
		class takeout {};
	};
};