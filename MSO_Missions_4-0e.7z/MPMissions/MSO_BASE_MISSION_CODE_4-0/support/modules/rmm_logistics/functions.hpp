class logistics {
	file = "support\modules\rmm_logistics";
	class functions {
		class load {};
		class move {};
		class open {};
		class unload {};
	};
};