Testing:
To test, move the LOGISTICS folder into MSOTesting.Zargabad\modules folder.

Launch using a dedicated server and perform the testing procedure before releasing:
- try packing ammo crate into both vehicles
- try unpacking ammo crate and confirm remaining space has returned
- try packing motorcycle into MTVR
- try packing motorcycle into Land Drover

Wolffy - Successfully tested on dedi 10/OCT/10