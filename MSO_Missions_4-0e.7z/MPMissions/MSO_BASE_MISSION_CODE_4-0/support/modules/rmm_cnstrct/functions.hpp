class cnstrct {
	file = "support\modules\rmm_cnstrct";
	class functions {
		class create {};
		class handler {};
		class open {};
		class refresh {};
		class sell {};
		class update {};
	};
};