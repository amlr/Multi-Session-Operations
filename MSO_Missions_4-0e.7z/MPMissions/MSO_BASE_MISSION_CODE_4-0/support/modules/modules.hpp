// - Tested
#define RMM_AAR
#define RMM_CAS
#define RMM_CASEVAC
#define CRB_TWNMGR
#define CRB_FLIPPABLE
#define RMM_JIPMARKERS
#define RMM_LOGBOOK
#define R3F_LOGISTICS
#define RMM_RECRUITMENT
#define RMM_REVIVE
#define RMM_TASKS
#define RMM_TYRES
#define WHB_MULTISPAWN

// WIP
//#define GC_PACK_COW
//#define TN_LHDELEVATOR
