class notebook {
	file = "support\modules\rmm_notebook";
	class functions {
		class open {};
	};
};