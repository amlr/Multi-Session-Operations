#include <msofactions_defaults.hpp>

	class faction_RU {
		title = "    Enable Russians"; 
		values[]= {0,1}; 
		texts[]= {"false","true"}; 
		default = DEFAULT_RU;
	};
	class faction_ACE_RU {
		title = "    Enable ACE Russians"; 
		values[]= {0,1}; 
		texts[]= {"false","true"}; 
		default = DEFAULT_ACE_RU;
	};
	class faction_INS {
		title = "    Enable Insurgents"; 
		values[]= {0,1}; 
		texts[]= {"false","true"}; 
		default = DEFAULT_INS;
	};
	class faction_GUE {
		title = "    Enable Guerillas"; 
		values[]= {0,1}; 
		texts[]= {"false","true"}; 
		default = DEFAULT_GUE;
	};
	class faction_BIS_TK {
		title = "    Enable Takistan Army"; 
		values[]= {0,1}; 
		texts[]= {"false","true"}; 
		default = DEFAULT_BIS_TK;
	};
	class faction_BIS_TK_INS {
		title = "    Enable Takistan Insurgency"; 
		values[]= {0,1}; 
		texts[]= {"false","true"}; 
		default = DEFAULT_BIS_TK_INS;
	};
	class faction_BIS_TK_GUE {
		title = "    Enable Takistan Guerillas"; 
		values[]= {0,1}; 
		texts[]= {"false","true"}; 
		default = DEFAULT_BIS_TK_GUE;
	};
	class faction_CWR2_US {
		title = "    Enable CWR2 US"; 
		values[]= {0,1}; 
		texts[]= {"false","true"}; 
		default = DEFAULT_CWR2_US;
	};
	class faction_CWR2_RU {
		title = "    Enable CWR2 Russians"; 
		values[]= {0,1}; 
		texts[]= {"false","true"}; 
		default = DEFAULT_CWR2_RU;
	};
	class faction_CWR2_FIA {
		title = "    Enable CWR2 Insurgents"; 
		values[]= {0,1}; 
		texts[]= {"false","true"}; 
		default = DEFAULT_CWR2_FIA;
	};
