class crb_tc_intensity {
        title = "    Civilian Terrorist Cells Recruitment per Hour (relies on Ambient Civs)"; 
        values[]= {0,1,2,3,4,5}; 
        texts[]= {"None","4 Recruits","2 Recruits","1 Recruit","0.5 Recruit","0.33 Recruit"}; 
        default = 2;
};
class crb_tc_markers {
        title = "        Civilian Terrorist Insurgency Style Markers"; 
        values[]= {0,1}; 
        texts[]= {"Off","On"}; 
        default = 1;
};



