class crb_convoy_intensity {
        title = "    Enemy Convoy Intensity"; 
        values[]= {0, 1, 2}; 
        texts[]= {"None","50%","Full"}; 
        default = 1;
};

