// - Tested
#define MSOFACTIONS
#define CRB_CONVOYS
#define RMM_ENEMYPOP
#define CRB_TERRORISTS
#define RMM_ZORA

// - To Test
#define WICT_ENEMYPOP
//#define BIS_WARFARE