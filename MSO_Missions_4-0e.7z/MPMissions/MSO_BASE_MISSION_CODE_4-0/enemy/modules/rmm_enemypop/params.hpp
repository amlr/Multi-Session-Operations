class enemyHeader {
        title = "Enemy"; 
        values[]= {0}; 
        texts[]= {" "}; 
        default = 0;
};
class rmm_ep_intensity {
        title = "    Enemy Intensity"; 
        values[]= {0,3,2,1}; 
        texts[]= {"Disabled","33%","50%","100%"}; 
        default = 3;
};
