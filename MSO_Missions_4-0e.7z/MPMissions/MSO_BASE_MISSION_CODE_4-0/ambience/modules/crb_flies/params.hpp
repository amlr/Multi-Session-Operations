class ambientFlies {
        title = "    Enable Fly Swarms"; 
        values[]= {0, 1}; 
        texts[]= {"Off","On"}; 
        default = 0;
};
