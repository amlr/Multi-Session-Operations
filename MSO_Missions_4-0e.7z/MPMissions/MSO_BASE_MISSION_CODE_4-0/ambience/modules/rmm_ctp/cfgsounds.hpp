class muezzin {
	name = "muezzin";
	sound[] = {"ambience\modules\rmm_ctp\sounds\muezzin.ogg", 1, 1};
	titles[] = {};
};