class scream {
	name = "scream";
	sound[] = {ambience\modules\crb_dogs\sounds\scream.ogg, 0.5, 1.0};
	titles[] = {};
};
class dog_maul01 {
	name = "dog_maul01";
	sound[] = {ambience\modules\crb_dogs\sounds\dog_maul01.ogg,0.5,1};
	titles[] = {};
};
class dog_yelp {
	name = "dog_yelp";
	sound[] = {ambience\modules\crb_dogs\sounds\dog_yelp.ogg,0.5,1};
	titles[] = {};
};
