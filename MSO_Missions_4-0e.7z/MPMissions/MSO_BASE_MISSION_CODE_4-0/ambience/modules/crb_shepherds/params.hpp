class ambientShepherds {
        title = "    Enable Shepherds"; 
        values[]= {0, 1}; 
        texts[]= {"Off","On"}; 
        default = 1;
};