class mprightsDisable {
	title = "MP Rights - Disable"; 
	values[]= {0,1}; 
	texts[]= {"false","true"}; 
	default = 1;
};