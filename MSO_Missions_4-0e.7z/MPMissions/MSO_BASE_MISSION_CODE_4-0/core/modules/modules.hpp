#define RMM_DEBUG
#define RMM_HELP
#define RMM_MP_RIGHTS
#define RMM_NOMAD
#define RMM_SETTINGS
#define RMM_WEATHER
#define SPYDER_ONU
#define NOU_CACHE

// To fix
//#define RMM_GTK
//#define RMM_OSL
//#define RMM_OSOM
//#define JCACHE
//#define CEP_CACHE



