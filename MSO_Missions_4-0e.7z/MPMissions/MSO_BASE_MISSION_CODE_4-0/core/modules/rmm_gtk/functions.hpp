class gtk {
	file = "core\modules\rmm_gtk";
	class functions {
		class forceActive {};
		class forceInactive {};
	};
};