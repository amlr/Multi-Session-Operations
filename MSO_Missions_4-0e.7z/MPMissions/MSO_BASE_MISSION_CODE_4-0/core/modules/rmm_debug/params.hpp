class debug_serverfps {
	title = "Debug - Server FPS to log"; 
	values[]= {0,30,60,180,300}; 
	texts[]= {"Off","30 sec", "1 min","3 min","5 min"}; 
	default = 0; 
};
