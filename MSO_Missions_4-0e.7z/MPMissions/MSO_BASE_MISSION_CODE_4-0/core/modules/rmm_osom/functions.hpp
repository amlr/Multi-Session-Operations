class osom {
	file = "core\modules\rmm_osom";
	class functions {
		class active {};
		class inactive {};
		class sync {};
		class spawn {};
	};
};