Testing:
To test, move the SETTINGS folder into MSOTesting.Zargabad\modules folder.

Launch using a dedicated server and perform the testing procedure before releasing:
- use a Radio trigger to createDialog
- test changing viewDistance and terrainGrid

Wolffy - Successfully tested on dedi 15/OCT/10