#define HASH_ID 0
#define HASH_KEYS 1
#define HASH_VALUES 2
#define HASH_DEFAULT_VALUE 3

#define TYPE_HASH "#CBA_HASH#"
