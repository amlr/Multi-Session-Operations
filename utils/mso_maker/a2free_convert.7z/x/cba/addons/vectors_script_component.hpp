#define COMPONENT vectors
#include "script_mod.hpp"


#ifdef DEBUG_ENABLED_VECTORS
	#define DEBUG_MODE_FULL
#endif

#ifdef DEBUG_SETTINGS_VECTORS
	#define DEBUG_SETTINGS DEBUG_SETTINGS_VECTORS
#endif

#include "script_macros.hpp"
