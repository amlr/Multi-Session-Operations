#define COMPONENT help
#include "script_mod.hpp"

#ifdef DEBUG_ENABLED_HELP
	#define DEBUG_MODE_FULL
#endif

#ifdef DEBUG_SETTINGS_HELP
	#define DEBUG_SETTINGS DEBUG_SETTINGS_HELP
#endif

#include "script_macros.hpp"
