#define COMPONENT network
#include "script_mod.hpp"


#ifdef DEBUG_ENABLED_NETWORK
	#define DEBUG_MODE_FULL
#endif

#ifdef DEBUG_SETTINGS_NETWORK
	#define DEBUG_SETTINGS DEBUG_SETTINGS_NETWORK
#endif

#include "script_macros.hpp"
