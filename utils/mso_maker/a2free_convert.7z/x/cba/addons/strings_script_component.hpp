#define COMPONENT strings
#include "script_mod.hpp"


#ifdef DEBUG_ENABLED_STRINGS
	#define DEBUG_MODE_FULL
#endif

#ifdef DEBUG_SETTINGS_STRINGS
	#define DEBUG_SETTINGS DEBUG_SETTINGS_STRINGS
#endif

#include "script_macros.hpp"
