#define COMPONENT versioning
#include "script_mod.hpp"


#ifdef DEBUG_ENABLED_VERSIONING
	#define DEBUG_MODE_FULL
#endif

#ifdef DEBUG_SETTINGS_VERSIONING
	#define DEBUG_SETTINGS DEBUG_SETTINGS_VERSIONING
#endif

#include "script_macros.hpp"
