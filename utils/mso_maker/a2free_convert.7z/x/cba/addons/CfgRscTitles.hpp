	class CBA_FrameHandlerTitle {
		idd = 40121;
		movingEnable = 1;
        enableSimulation = 1;
        enableDisplay = 1;

        onLoad = QUOTE(_this call CBA_common_fnc_perFrameEngine);

        duration = 99999999999999999;
        fadein  = 0;
        fadeout = 0;
		name = "CBA_FrameHandlerTitle";
		class controlsBackground {
			class dummy_map : CBA_Dummy_Map {
				idc = 40122;
				x = 0;
				y = 0;
				w = 0;
				h = 0;
			};
		};
		class objects {

		};
		class controls {

		};
	};
