
	class CBA
	{
		class Misc
		{
			// CBA_fnc_actionArgument
			class actionArgument
			{
				description = "Used to call the code parsed in the addaction argument.";
				file = "x\cba\addons\common_fnc_actionArgument.sqf";
			};
			// CBA_fnc_addMagazine
			class addMagazine
			{
				description = "Add magazine to a vehicle/unit.";
				file = "x\cba\addons\common_fnc_addMagazine.sqf";
			};
			// CBA_fnc_addMagazineCargo
			class addMagazineCargo
			{
				description = "Add magazine(s) to a vehicle's cargo.";
				file = "x\cba\addons\common_fnc_addMagazineCargo.sqf";
			};
			// CBA_fnc_addMagazineVerified
			class addMagazineVerified
			{
				description = "Add magazines to the player, but verify that it was successful and doesn't over-burden the recipient. The function will fill all available inventory slots with the requested magazine type.";
				file = "x\cba\addons\common_fnc_addMagazineVerified.sqf";
			};
			// CBA_fnc_addPerFrameHandler
			class addPerFrameHandler
			{
				description = "Add a handler that will execute every frame, or every x number of seconds";
				file = "x\cba\addons\common_fnc_addPerFrameHandler.sqf";
			};
			// CBA_fnc_addPlayerAction
			class addPlayerAction
			{
				description = "Adds persistent action to player (which will also be available in vehicles and after respawn or teamswitch).";
				file = "x\cba\addons\common_fnc_addPlayerAction.sqf";
			};
			// CBA_fnc_addWeapon
			class addWeapon
			{
				description = "Add a weapon to a unit.";
				file = "x\cba\addons\common_fnc_addWeapon.sqf";
			};
			// CBA_fnc_addWeaponCargo
			class addWeaponCargo
			{
				description = "Add weapon(s) to vehicle cargo.";
				file = "x\cba\addons\common_fnc_addWeaponCargo.sqf";
			};
			// CBA_fnc_createCenter
			class createCenter
			{
				description = "Selects center if it already exists, creates it if it doesn't yet.";
				file = "x\cba\addons\common_fnc_createCenter.sqf";
			};
			// CBA_fnc_createMarker
			class createMarker
			{
				description = "Creates a marker all at once.";
				file = "x\cba\addons\common_fnc_createMarker.sqf";
			};
			// CBA_fnc_createTrigger
			class createTrigger
			{
				description = "Create a trigger all at once.";
				file = "x\cba\addons\common_fnc_createTrigger.sqf";
			};
			// CBA_fnc_defaultParam
			class defaultParam
			{
				description = "Gets a value from parameters list (usually _this) with a default.";
				file = "x\cba\addons\common_fnc_defaultParam.sqf";
			};
			// CBA_fnc_deleteEntity
			class deleteEntity
			{
				description = "A function used to delete entities Parameters: Array, Object, Group or Marker Example: [car1,car2,car3] call CBA_fnc_deleteEntity Returns: Nothing Author: Rommel";
				file = "x\cba\addons\common_fnc_deleteEntity.sqf";
			};
			// CBA_fnc_determineMuzzles
			class determineMuzzles
			{
				description = "Gets the list of possible muzzles for a weapon.";
				file = "x\cba\addons\common_fnc_determineMuzzles.sqf";
			};
			// CBA_fnc_dropMagazine
			class dropMagazine
			{
				description = "Drop a magazine.";
				file = "x\cba\addons\common_fnc_dropMagazine.sqf";
			};
			// CBA_fnc_dropWeapon
			class dropWeapon
			{
				description = "Drops a weapon.";
				file = "x\cba\addons\common_fnc_dropWeapon.sqf";
			};
			// CBA_fnc_findEntity
			class findEntity
			{
				description = "A function used to find out the first entity of parsed type in a nearEntitys call Parameters: - Type (Classname, Object) - Position (XYZ, Object, Location or Group) Optional: - Radius (Scalar) Example: _veh = [""LaserTarget"", player] call CBA_fnc_findEntity Returns: First entity; nil return if nothing Author: Rommel";
				file = "x\cba\addons\common_fnc_findEntity.sqf";
			};
			// CBA_fnc_getAlive
			class getAlive
			{
				description = "A function used to find out who is alive in an array or a group. Parameters: Array, Group or Unit Example: _alive = (Units player) call CBA_fnc_getAlive Returns: Array Author: Rommel";
				file = "x\cba\addons\common_fnc_getAlive.sqf";
			};
			// CBA_fnc_getAnimType
			class getAnimType
			{
				description = "Used to determine which weapon unit is currently holding and return proper animation type.";
				file = "x\cba\addons\common_fnc_getAnimType.sqf";
			};
			// CBA_fnc_getArg
			class getArg
			{
				description = "Get default named argument from list.";
				file = "x\cba\addons\common_fnc_getArg.sqf";
			};
			// CBA_fnc_getAspectRatio
			class getAspectRatio
			{
				description = "Used to determine the Aspect ratio of the screen.";
				file = "x\cba\addons\common_fnc_getAspectRatio.sqf";
			};
			// CBA_fnc_getConfigEntry
			class getConfigEntry
			{
				description = "Gets a configuration entry.";
				file = "x\cba\addons\common_fnc_getConfigEntry.sqf";
			};
			// CBA_fnc_getDistance
			class getDistance
			{
				description = "A function used to find out the distance between two positions. Parameters: Array containing two of [Marker, Object, Location, Group or Position] Example: _distance = [Player, [0,0,0]] call CBA_fnc_getDistance Returns: Number - Distance in meters Author: Rommel";
				file = "x\cba\addons\common_fnc_getDistance.sqf";
			};
			// CBA_fnc_getFirer
			class getFirer
			{
				description = "A function used to find out which unit exactly fired (Replacement for gunner, on multi-turret vehicles). Parameters: Vehicle that fired Weapon that was used Example: _unit = player call CBA_fnc_getFirer Returns: Unit Turretpath Author: Rocko";
				file = "x\cba\addons\common_fnc_getFirer.sqf";
			};
			// CBA_fnc_getFov
			class getFov
			{
				description = "Get current camera's field of view in radians and zoom. Fov is calculated in the same format as it is set up in configs and used by camSetFov and alike. Precision is about 95%.";
				file = "x\cba\addons\common_fnc_getFov.sqf";
			};
			// CBA_fnc_getGroup
			class getGroup
			{
				description = "A function used to find out the group of an object. Parameters: Group or Unit Example: _group = player call CBA_fnc_getGroup Returns: Group Author: Rommel";
				file = "x\cba\addons\common_fnc_getGroup.sqf";
			};
			// CBA_fnc_getGroupIndex
			class getGroupIndex
			{
				description = "Finds out the actual ID number of a person within his group as assigned by the game and used in the squad leader's command menu, not just the order within the units of his group (this order can change due to players joining and leaving the game, deaths or promotions).";
				file = "x\cba\addons\common_fnc_getGroupIndex.sqf";
			};
			// CBA_fnc_getNearest
			class getNearest
			{
				description = "A function used to find out the nearest entity parsed in an array to a position. Compares the distance between entity's in the parsed array. Parameters: _position - Marker, Object, Location, Group or Position _array - Array of [Marker, Object, Location, Group and or Positions] _radius - Maximum distance from _position _code - Condition to meet (Code) Example: _nearestVeh = [player, vehicles] call CBA_fnc_getNearest _nearestGroups = [[0,0,0], allGroups, 50, {count (units _x) > 1}] call CBA_fnc_getNearest Returns: Nearest given entity or List of entities within given distance Author: Rommel";
				file = "x\cba\addons\common_fnc_getNearest.sqf";
			};
			// CBA_fnc_getNearestBuilding
			class getNearestBuilding
			{
				description = "A function used to find out the nearest building and appropriate building positions available. Parameters: Object Example: _array = player call CBA_fnc_getNearestBuilding Returns: Array with [building object, building positions (count)] Author: Rommel ---------------------------------------------------------------------------- */";
				file = "x\cba\addons\common_fnc_getNearestBuilding.sqf";
			};
			// CBA_fnc_getPistol
			class getPistol
			{
				description = "Returns name of pistol in unit's inventory, if any.";
				file = "x\cba\addons\common_fnc_getPistol.sqf";
			};
			// CBA_fnc_getPos
			class getPos
			{
				description = "A function used to get the position of an entity. Parameters: Marker, Object, Location, Group or Position Example: _position = (group player) call CBA_fnc_getPos Returns: Position (AGL) - [X,Y,Z] Author: Rommel";
				file = "x\cba\addons\common_fnc_getPos.sqf";
			};
			// CBA_fnc_getSharedGroup
			class getSharedGroup
			{
				description = "Returns existing group on side, or newly created group when not existent.";
				file = "x\cba\addons\common_fnc_getSharedGroup.sqf";
			};
			// CBA_fnc_getTerrainProfile
			class getTerrainProfile
			{
				description = "A function used to find the terrain profile between two positions";
				file = "x\cba\addons\common_fnc_getTerrainProfile.sqf";
			};
			// CBA_fnc_getTurret
			class getTurret
			{
				description = "A function used to find out which config turret is turretpath. Parameters: Vehicle Turretpath Example: _config = [vehicle player, [0]] call CBA_fnc_getTurret Returns: Turret Config entry Author: Sickboy";
				file = "x\cba\addons\common_fnc_getTurret.sqf";
			};
			// CBA_fnc_getUISize
			class getUISize
			{
				description = "Used to determine the UI size of the screen.";
				file = "x\cba\addons\common_fnc_getUISize.sqf";
			};
			// CBA_fnc_getUnitAnim
			class getUnitAnim
			{
				description = "Get information about a unit's stance and speed.";
				file = "x\cba\addons\common_fnc_getUnitAnim.sqf";
			};
			// CBA_fnc_getUnitDeathAnim
			class getUnitDeathAnim
			{
				description = "Get death animation for a unit.";
				file = "x\cba\addons\common_fnc_getUnitDeathAnim.sqf";
			};
			// CBA_fnc_getVolume
			class getVolume
			{
				description = "Return the volume of an object based on the object's model's bounding box.";
				file = "x\cba\addons\common_fnc_getVolume.sqf";
			};
			// CBA_fnc_headDir
			class headDir
			{
				description = "Get the direction of a unit's head.";
				file = "x\cba\addons\common_fnc_headDir.sqf";
			};
			// CBA_fnc_inArea
			class inArea
			{
				description = "A function used to determine if a position is within a zone.";
				file = "x\cba\addons\common_fnc_inArea.sqf";
			};
			// CBA_fnc_inheritsFrom
			class inheritsFrom
			{
				description = "Checks whether a config entry inherits, directly or indirectly, from another one.";
				file = "x\cba\addons\common_fnc_inheritsFrom.sqf";
			};
			// CBA_fnc_isAlive
			class isAlive
			{
				description = "A function used to find out if the group or object is alive. Parameters: Array, Group or Unit Example: _alive = (Units player) call CBA_fnc_getAlive Returns: Boolean Author: Rommel";
				file = "x\cba\addons\common_fnc_isAlive.sqf";
			};
			// CBA_fnc_isTurnedOut
			class isTurnedOut
			{
				description = "Checks whether a unit is turned out in a vehicle or not.";
				file = "x\cba\addons\common_fnc_isTurnedOut.sqf";
			};
			// CBA_fnc_isUnitGetOutAnim
			class isUnitGetOutAnim
			{
				description = "Checks whether a unit is turned out in a vehicle or not.";
				file = "x\cba\addons\common_fnc_isUnitGetOutAnim.sqf";
			};
			// CBA_fnc_mapDirTo
			class mapDirTo
			{
				description = "Gets the direction between two map grid references.";
				file = "x\cba\addons\common_fnc_mapDirTo.sqf";
			};
			// CBA_fnc_mapGridToPos
			class mapGridToPos
			{
				description = "Converts a 2, 4, 6, 8, or 10 digit grid reference into a Position.";
				file = "x\cba\addons\common_fnc_mapGridToPos.sqf";
			};
			// CBA_fnc_mapRelPos
			class mapRelPos
			{
				description = "Find a position relative to a known position on the map. Passing strings in for the Northing and Easting is the preferred way.";
				file = "x\cba\addons\common_fnc_mapRelPos.sqf";
			};
			// CBA_fnc_modelHeadDir
			class modelHeadDir
			{
				description = "Get the direction of any unit's head.";
				file = "x\cba\addons\common_fnc_modelHeadDir.sqf";
			};
			// CBA_fnc_nearPlayer
			class nearPlayer
			{
				description = "Check whether these are any players within a certain distance of a unit.";
				file = "x\cba\addons\common_fnc_nearPlayer.sqf";
			};
			// CBA_fnc_northingReversed
			class northingReversed
			{
				description = "Checks if the maps northing is reversed (like Chernarus & Utes, or any map pre-OA)";
				file = "x\cba\addons\common_fnc_northingReversed.sqf";
			};
			// CBA_fnc_objectRandom
			class objectRandom
			{
				description = "Creates a ""random"" number 0-9 based on an object's velocity";
				file = "x\cba\addons\common_fnc_objectRandom.sqf";
			};
			// CBA_fnc_parseYAML
			class parseYAML
			{
				description = "Parses a YAML file into a nested array/Hash structure.";
				file = "x\cba\addons\common_fnc_parseYAML.sqf";
			};
			// CBA_fnc_players
			class players
			{
				description = "Get a list of current player objects.";
				file = "x\cba\addons\common_fnc_players.sqf";
			};
			// CBA_fnc_randPos
			class randPos
			{
				description = "A function used to randomize a position around a given center Parameters: Marker, Object, Location, Group or Position, Radius Example: _position =  [position, radius] call CBA_fnc_randPos Returns: Position - [X,Y,Z] Author: Rommel";
				file = "x\cba\addons\common_fnc_randPos.sqf";
			};
			// CBA_fnc_realHeight
			class realHeight
			{
				description = "Real z coordinate of an object, for placing stuff on roofs, etc.";
				file = "x\cba\addons\common_fnc_realHeight.sqf";
			};
			// CBA_fnc_removeMagazine
			class removeMagazine
			{
				description = "Remove a magazine.";
				file = "x\cba\addons\common_fnc_removeMagazine.sqf";
			};
			// CBA_fnc_removePerFrameHandler
			class removePerFrameHandler
			{
				description = "Remove a handler that you have added using CBA_fnc_addPerFrameHandler";
				file = "x\cba\addons\common_fnc_removePerFrameHandler.sqf";
			};
			// CBA_fnc_removePlayerAction
			class removePlayerAction
			{
				description = "Removes player action previously added with <CBA_fnc_addPlayerAction>.";
				file = "x\cba\addons\common_fnc_removePlayerAction.sqf";
			};
			// CBA_fnc_removeWeapon
			class removeWeapon
			{
				description = "Remove a weapon.";
				file = "x\cba\addons\common_fnc_removeWeapon.sqf";
			};
			// CBA_fnc_selectWeapon
			class selectWeapon
			{
				description = "Selects weapon, if the player has the weapon, including correctly selecting a muzzle, if any.";
				file = "x\cba\addons\common_fnc_selectWeapon.sqf";
			};
			// CBA_fnc_setHeight
			class setHeight
			{
				description = "A function used to set the height of an object Parameters: _object - Object or Location _height - Height in metres _type - Optional parameter, 0 is getpos, 1 is getpos ASL, 2 is getposATL (Default: 1) Example: [this, 10] call CBA_fnc_setHeight Returns: Nothing Author: Rommel";
				file = "x\cba\addons\common_fnc_setHeight.sqf";
			};
			// CBA_fnc_setPos
			class setPos
			{
				description = "A function used to set the position of an entity. Parameters: Marker, Object, Location, Group or Position Example: [player, ""respawn_west""] call CBA_fnc_setPos Returns: Nil Author: Rommel";
				file = "x\cba\addons\common_fnc_setPos.sqf";
			};
			// CBA_fnc_switchPlayer
			class switchPlayer
			{
				description = "Switch player to another unit.";
				file = "x\cba\addons\common_fnc_switchPlayer.sqf";
			};
			// CBA_fnc_systemChat
			class systemChat
			{
				description = "Display a message in the global chat channel.";
				file = "x\cba\addons\common_fnc_systemChat.sqf";
			};
		};
		class Ai
		{
			// CBA_fnc_addWaypoint
			class addWaypoint
			{
				description = "A function used to add a waypoint to a group. Parameters: - Group (Group or Object) - Position (XYZ, Object, Location or Group) Optional: - Radius (Scalar) - Waypoint Type (String) - Behaviour (String) - Combat Mode (String) - Speed Mode (String) - Formation (String) - Code To Execute at Each Waypoint (String) - TimeOut at each Waypoint (Array [Min, Med, Max]) - Waypoint Completion Radius (Scalar) Example: [this, this, 300, ""MOVE"", ""AWARE"", ""YELLOW"", ""FULL"", ""STAG COLUMN"", ""this spawn CBA_fnc_searchNearby"", [3,6,9]] Returns: Waypoint Author: Rommel";
				file = "x\cba\addons\ai_fnc_addWaypoint.sqf";
			};
			// CBA_fnc_searchNearby
			class searchNearby
			{
				description = "A function for a group to search a nearby building. Parameters: Group (Group or Object) Example: [group player] spawn CBA_fnc_searchNearby Returns: Nil Author: Rommel";
				file = "x\cba\addons\ai_fnc_searchNearby.sqf";
			};
			// CBA_fnc_taskAttack
			class taskAttack
			{
				description = "A function for a group to attack a parsed location. Parameters: - Group (Group or Object) - Position (XYZ, Object, Location or Group) Optional: - Search Radius (Scalar) Example: [group player, getpos (player findNearestEnemy player), 100] call CBA_fnc_taskAttack Returns: Nil Author: Rommel";
				file = "x\cba\addons\ai_fnc_taskAttack.sqf";
			};
			// CBA_fnc_taskDefend
			class taskDefend
			{
				description = "A function for a group to defend a parsed location. Groups will mount nearby static machine guns, and bunker in nearby buildings. They may also patrol the radius unless otherwise specified. Parameters: - Group (Group or Object) Optional: - Position (XYZ, Object, Location or Group) - Defend Radius (Scalar) - Building Size Threshold (Integer, default 2) - Can patrol (boolean) Example: [this] call CBA_fnc_taskDefend Returns: Nil Author: Rommel";
				file = "x\cba\addons\ai_fnc_taskDefend.sqf";
			};
			// CBA_fnc_taskPatrol
			class taskPatrol
			{
				description = "A function for a group to randomly patrol a parsed radius and location. Parameters: - Group (Group or Object) Optional: - Position (XYZ, Object, Location or Group) - Radius (Scalar) - Waypoint Count (Scalar) - Waypoint Type (String) - Behaviour (String) - Combat Mode (String) - Speed Mode (String) - Formation (String) - Code To Execute at Each Waypoint (String) - TimeOut at each Waypoint (Array [Min, Med, Max]) Example: [this, getmarkerpos ""objective1""] call CBA_fnc_taskPatrol [this, this, 300, 7, ""MOVE"", ""AWARE"", ""YELLOW"", ""FULL"", ""STAG COLUMN"", ""this spawn CBA_fnc_searchNearby"", [3,6,9]] call CBA_fnc_taskPatrol;";
				file = "x\cba\addons\ai_fnc_taskPatrol.sqf";
			};
		};
		class Arrays
		{
			// CBA_fnc_filter
			class filter
			{
				description = "Filter each element of an array via a function.";
				file = "x\cba\addons\arrays_fnc_filter.sqf";
			};
			// CBA_fnc_getArrayDiff
			class getArrayDiff
			{
				description = "A function used to return the differences between two arrays. Parameters: Two Arrays of strings (must not contain scalars) Example: _distance = [[0,0,1], [0,0,0]] call CBA_fnc_getArrayDiff Returns: Array Differences (for above example, return is [[1],[0]]) Author: Rommel";
				file = "x\cba\addons\arrays_fnc_getArrayDiff.sqf";
			};
			// CBA_fnc_getArrayElements
			class getArrayElements
			{
				description = "A function used to return the element counts in an array. Parameters: Array Example: _types = [0,0,1,1,1,1] call CBA_fnc_getArrayElements Returns: Array element counts (for above example, return would be [0,2,1,4]) Author: Rommel && sbsmac";
				file = "x\cba\addons\arrays_fnc_getArrayElements.sqf";
			};
			// CBA_fnc_inject
			class inject
			{
				description = "Accumulates a value by passing elements of an array ""through"" a function.";
				file = "x\cba\addons\arrays_fnc_inject.sqf";
			};
			// CBA_fnc_join
			class join
			{
				description = "Joins an array of values into a single string, joining each fragment around a separator string. Inverse of <CBA_fnc_split>.";
				file = "x\cba\addons\arrays_fnc_join.sqf";
			};
			// CBA_fnc_shuffle
			class shuffle
			{
				description = "Shuffles an array's contents into random order, returning a new array.";
				file = "x\cba\addons\arrays_fnc_shuffle.sqf";
			};
			// CBA_fnc_sortNestedArray
			class sortNestedArray
			{
				description = "Used to sort a nested array from lowest to highest using quick sort based on the specified column, which must have numerical data. Parameters: _array: array - Nested array to be sorted _index: integer - sub array item index to be sorted on Example: _array = [_array,1] call CBA_fnc_sortNestedArray Returns: Passed in array Author: Standard algorithm";
				file = "x\cba\addons\arrays_fnc_sortNestedArray.sqf";
			};
		};
		class Events
		{
			// CBA_fnc_addDisplayHandler
			class addDisplayHandler
			{
				description = "Adds an action to a displayHandler";
				file = "x\cba\addons\events_fnc_addDisplayHandler.sqf";
			};
			// CBA_fnc_addEventHandler
			class addEventHandler
			{
				description = "Registers an event handler for a specific CBA event.";
				file = "x\cba\addons\events_fnc_addEventHandler.sqf";
			};
			// CBA_fnc_addKeyHandler
			class addKeyHandler
			{
				description = "Adds an action to a keyhandler";
				file = "x\cba\addons\events_fnc_addKeyHandler.sqf";
			};
			// CBA_fnc_addKeyHandlerFromConfig
			class addKeyHandlerFromConfig
			{
				description = "Adds an action to a keyhandler, read from config";
				file = "x\cba\addons\events_fnc_addKeyHandlerFromConfig.sqf";
			};
			// CBA_fnc_addLocalEventHandler
			class addLocalEventHandler
			{
				description = "Registers an event handler for a specific CBA event which only runs where the first parameter (object) is local.";
				file = "x\cba\addons\events_fnc_addLocalEventHandler.sqf";
			};
			// CBA_fnc_changeKeyHandler
			class changeKeyHandler
			{
				description = "Changes an action to a keyhandler";
				file = "x\cba\addons\events_fnc_changeKeyHandler.sqf";
			};
			// CBA_fnc_globalEvent
			class globalEvent
			{
				description = "Raises a CBA event on all machines, including the local one.";
				file = "x\cba\addons\events_fnc_globalEvent.sqf";
			};
			// CBA_fnc_localEvent
			class localEvent
			{
				description = "Raises a CBA event only on the local machine.";
				file = "x\cba\addons\events_fnc_localEvent.sqf";
			};
			// CBA_fnc_readKeyFromConfig
			class readKeyFromConfig
			{
				description = "Reads key setting from config";
				file = "x\cba\addons\events_fnc_readKeyFromConfig.sqf";
			};
			// CBA_fnc_remoteEvent
			class remoteEvent
			{
				description = "Raises a CBA event on all machines EXCEPT the local one.";
				file = "x\cba\addons\events_fnc_remoteEvent.sqf";
			};
			// CBA_fnc_remoteLocalEvent
			class remoteLocalEvent
			{
				description = "Raises a CBA event only on the machine where parameter one is local.";
				file = "x\cba\addons\events_fnc_remoteLocalEvent.sqf";
			};
			// CBA_fnc_removeDisplayHandler
			class removeDisplayHandler
			{
				description = "Removes an action to a displayHandler";
				file = "x\cba\addons\events_fnc_removeDisplayHandler.sqf";
			};
			// CBA_fnc_removeEventHandler
			class removeEventHandler
			{
				description = "Removes an event handler previously registered with CBA_fnc_addEventHandler.";
				file = "x\cba\addons\events_fnc_removeEventHandler.sqf";
			};
			// CBA_fnc_removeKeyHandler
			class removeKeyHandler
			{
				description = "Removes an action to a keyhandler";
				file = "x\cba\addons\events_fnc_removeKeyHandler.sqf";
			};
			// CBA_fnc_removeLocalEventHandler
			class removeLocalEventHandler
			{
				description = "Removes an event handler previously registered with CBA_fnc_addLocalEventHandler.";
				file = "x\cba\addons\events_fnc_removeLocalEventHandler.sqf";
			};
			// CBA_fnc_whereLocalEvent
			class whereLocalEvent
			{
				description = "Raises a CBA event only on the machine where parameter one is local.";
				file = "x\cba\addons\events_fnc_whereLocalEvent.sqf";
			};
		};
		class Diagnostic
		{
			// CBA_fnc_benchmarkFunction
			class benchmarkFunction
			{
				description = "Benchmarks a function to see how long it will take to execute.";
				file = "x\cba\addons\diagnostic_fnc_benchmarkFunction.sqf";
			};
			// CBA_fnc_debug
			class debug
			{
				description = "General Purpose Debug Message Writer";
				file = "x\cba\addons\diagnostic_fnc_debug.sqf";
			};
			// CBA_fnc_error
			class error
			{
				description = "Logs an error message to the RPT log.";
				file = "x\cba\addons\diagnostic_fnc_error.sqf";
			};
			// CBA_fnc_log
			class log
			{
				description = "Logs a message to the RPT log.";
				file = "x\cba\addons\diagnostic_fnc_log.sqf";
			};
			// CBA_fnc_peek
			class peek
			{
				description = "Peek at variable on the server To receive the variable content back, you will have to [""cba_diagnostics_receive_peak"", {_this call myFunction}] call CBA_fnc_addEventHandler;";
				file = "x\cba\addons\diagnostic_fnc_peek.sqf";
			};
			// CBA_fnc_test
			class test
			{
				description = "Runs unit tests for an addon or component.";
				file = "x\cba\addons\diagnostic_fnc_test.sqf";
			};
		};
		class Hashes
		{
			// CBA_fnc_hashCreate
			class hashCreate
			{
				description = "Check if a Hash has a value defined for a key.";
				file = "x\cba\addons\hashes_fnc_hashCreate.sqf";
			};
			// CBA_fnc_hashEachPair
			class hashEachPair
			{
				description = "Iterate through all keys and values in a Hash.";
				file = "x\cba\addons\hashes_fnc_hashEachPair.sqf";
			};
			// CBA_fnc_hashGet
			class hashGet
			{
				description = "Gets a value for a given key from a Hash.";
				file = "x\cba\addons\hashes_fnc_hashGet.sqf";
			};
			// CBA_fnc_hashHasKey
			class hashHasKey
			{
				description = "Check if a Hash has a value defined for a key.";
				file = "x\cba\addons\hashes_fnc_hashHasKey.sqf";
			};
			// CBA_fnc_hashRem
			class hashRem
			{
				description = "Removes given key from given Hash.";
				file = "x\cba\addons\hashes_fnc_hashRem.sqf";
			};
			// CBA_fnc_hashSet
			class hashSet
			{
				description = "Sets a value for a given key in a Hash.";
				file = "x\cba\addons\hashes_fnc_hashSet.sqf";
			};
			// CBA_fnc_isHash
			class isHash
			{
				description = "Check if a value is a Hash data structure.";
				file = "x\cba\addons\hashes_fnc_isHash.sqf";
			};
		};
		class Network
		{
			// CBA_fnc_getMarkerPersistent
			class getMarkerPersistent
			{
				description = "Checks if a global marker is persistent for JIP players.";
				file = "x\cba\addons\network_fnc_getMarkerPersistent.sqf";
			};
			// CBA_fnc_globalExecute
			class globalExecute
			{
				description = "Executes code on given destinations";
				file = "x\cba\addons\network_fnc_globalExecute.sqf";
			};
			// CBA_fnc_globalSay
			class globalSay
			{
				description = "Says sound on all client computer";
				file = "x\cba\addons\network_fnc_globalSay.sqf";
			};
			// CBA_fnc_globalSay3d
			class globalSay3d
			{
				description = "Says sound on all client computer in 3d";
				file = "x\cba\addons\network_fnc_globalSay3d.sqf";
			};
			// CBA_fnc_publicVariable
			class publicVariable
			{
				description = "CBA_fnc_publicVariable does only broadcast the new value if it doesn't exist in missionNamespace or the new value is different to the one in missionNamespace. Checks also for different types. Nil as value gets always broadcasted.";
				file = "x\cba\addons\network_fnc_publicVariable.sqf";
			};
			// CBA_fnc_setMarkerPersistent
			class setMarkerPersistent
			{
				description = "Sets or unsets JIP persistency on a global marker.";
				file = "x\cba\addons\network_fnc_setMarkerPersistent.sqf";
			};
			// CBA_fnc_setVarNet
			class setVarNet
			{
				description = "Same as setVariable [""name"",var, true] but only broadcasts when the value of var is different to the one which is already saved in the variable space. Checks also for different types. Nil as value gets always broadcasted.";
				file = "x\cba\addons\network_fnc_setVarNet.sqf";
			};
		};
		class Strings
		{
			// CBA_fnc_capitalize
			class capitalize
			{
				description = "Upper case the first letter of the string, lower case the rest.";
				file = "x\cba\addons\strings_fnc_capitalize.sqf";
			};
			// CBA_fnc_find
			class find
			{
				description = "Finds a string within another string.";
				file = "x\cba\addons\strings_fnc_find.sqf";
			};
			// CBA_fnc_formatElapsedTime
			class formatElapsedTime
			{
				description = "Formats time in seconds according to a format. Intended to show time elapsed, rather than time-of-day.";
				file = "x\cba\addons\strings_fnc_formatElapsedTime.sqf";
			};
			// CBA_fnc_formatNumber
			class formatNumber
			{
				description = "Formats a number to a minimum integer width and to a specific number of decimal places (including padding with 0s and correct rounding). Numbers are always displayed fully, never being condensed using an exponent (e.g. the number 1.234e9 would be given as ""1234000000"").";
				file = "x\cba\addons\strings_fnc_formatNumber.sqf";
			};
			// CBA_fnc_leftTrim
			class leftTrim
			{
				description = "Trims white-space (space, tab, newline) from the left end of a string.";
				file = "x\cba\addons\strings_fnc_leftTrim.sqf";
			};
			// CBA_fnc_replace
			class replace
			{
				description = "Replaces substrings within a string. Case-dependent.";
				file = "x\cba\addons\strings_fnc_replace.sqf";
			};
			// CBA_fnc_rightTrim
			class rightTrim
			{
				description = "Trims white-space (space, tab, newline) from the right end of a string.";
				file = "x\cba\addons\strings_fnc_rightTrim.sqf";
			};
			// CBA_fnc_split
			class split
			{
				description = "Splits a string into substrings using a separator. Inverse of <CBA_fnc_join>.";
				file = "x\cba\addons\strings_fnc_split.sqf";
			};
			// CBA_fnc_strLen
			class strLen
			{
				description = "Counts the number of characters in a string.";
				file = "x\cba\addons\strings_fnc_strLen.sqf";
			};
			// CBA_fnc_trim
			class trim
			{
				description = "Trims white-space (space, tab, newline) from the both ends of a string.";
				file = "x\cba\addons\strings_fnc_trim.sqf";
			};
		};
		class UI {
			class flexiMenu_Add {
				description = "Add a type-based menu source. Result: TBA (WIP)";
				file = "x\cba\addons\ui_flexiMenu_fnc_add.sqf";
			};
			class flexiMenu_Remove {
				description = "Remove a type-based menu source. Result: TBA (WIP)";
				file = "x\cba\addons\ui_flexiMenu_fnc_remove.sqf";
			};
			class flexiMenu_setObjectMenuSource {
				description = "Set an object's menu source (variable). Result: TBA (WIP)";
				file = "x\cba\addons\ui_flexiMenu_fnc_setObjectMenuSource.sqf";
			};
		};
		class Vectors
		{
			// CBA_fnc_polar2vect
			class polar2vect
			{
				description = "Creates a vector based on a inputted magnitude, direction and elevation";
				file = "x\cba\addons\vectors_fnc_polar2vect.sqf";
			};
			// CBA_fnc_scaleVect
			class scaleVect
			{
				description = "scales a specified vector by a specified factor.";
				file = "x\cba\addons\vectors_fnc_scaleVect.sqf";
			};
			// CBA_fnc_scaleVectTo
			class scaleVectTo
			{
				description = "scales a vector so that its new Magnitude is equivalent to a specified value.";
				file = "x\cba\addons\vectors_fnc_scaleVectTo.sqf";
			};
			// CBA_fnc_simplifyAngle
			class simplifyAngle
			{
				description = "Returns an equivalent angle to the specified angle in the range 0 to 360. This allows adjustment from negative angles and angles equal or greater to 360. If the inputted angle is in the range 0 - 360, it will be returned unchanged.";
				file = "x\cba\addons\vectors_fnc_simplifyAngle.sqf";
			};
			// CBA_fnc_simplifyAngle180
			class simplifyAngle180
			{
				description = "Returns an equivalent angle to the specified angle in the range -180 to 180. If the inputted angle is in the range -180 to 180, it will be returned unchanged.";
				file = "x\cba\addons\vectors_fnc_simplifyAngle180.sqf";
			};
			// CBA_fnc_vect2polar
			class vect2polar
			{
				description = "Parameters:";
				file = "x\cba\addons\vectors_fnc_vect2polar.sqf";
			};
			// CBA_fnc_vectAdd
			class vectAdd
			{
				description = "Returns the sum of two vectors.  Vectors can be 2D or 3D";
				file = "x\cba\addons\vectors_fnc_vectAdd.sqf";
			};
			// CBA_fnc_vectCross
			class vectCross
			{
				description = "Returns the cross product vector of two vectors.  Vectors must both be three dimensional.";
				file = "x\cba\addons\vectors_fnc_vectCross.sqf";
			};
			// CBA_fnc_vectCross2D
			class vectCross2D
			{
				description = "Returns the cross product vector of two 2D vectors. The result is an integer value (positive or negative), representing the magnitude of the height component.";
				file = "x\cba\addons\vectors_fnc_vectCross2D.sqf";
			};
			// CBA_fnc_vectDir
			class vectDir
			{
				description = "Returns the angle of a vector with the given i and k coordinates in the range 0 to 360.";
				file = "x\cba\addons\vectors_fnc_vectDir.sqf";
			};
			// CBA_fnc_vectDot
			class vectDot
			{
				description = "Returns the dot product of two vectors.  Vectors can be either two or three dimesions, but they must be the same dimension.";
				file = "x\cba\addons\vectors_fnc_vectDot.sqf";
			};
			// CBA_fnc_vectElev
			class vectElev
			{
				description = "Returns the angle of elevation of a 3D vector with the given i, j and k coordinates in the range -90 to 90.";
				file = "x\cba\addons\vectors_fnc_vectElev.sqf";
			};
			// CBA_fnc_vectMagn
			class vectMagn
			{
				description = "Returns the magnitude of a 3D vector with the given i, j and k coordinates.";
				file = "x\cba\addons\vectors_fnc_vectMagn.sqf";
			};
			// CBA_fnc_vectMagn2D
			class vectMagn2D
			{
				description = "Returns the magnitude of a vector with the given i and k coordinates or the magnitude of the i and k components of a 3D vector.";
				file = "x\cba\addons\vectors_fnc_vectMagn2D.sqf";
			};
			// CBA_fnc_vectRotate2D
			class vectRotate2D
			{
				description = "Rotates a 2D vector around a given center, for rotating of a vector from its origin, use BIS_fnc_rotateVector2D";
				file = "x\cba\addons\vectors_fnc_vectRotate2D.sqf";
			};
			// CBA_fnc_vectSubtract
			class vectSubtract
			{
				description = "Returns the difference of two vectors.  Vectors can be 2D or 3D.";
				file = "x\cba\addons\vectors_fnc_vectSubtract.sqf";
			};
		};
	};
	// Need to be manually maintained
	// Missing BIS functions
	class BIS {
		class variables {
			class undefCheck {
				file = "x\cba\addons\dummy.sqf";
			};
		};
	};
	class BIS_PMC {
		class PMC_Campaign {
			class initIdentity {
				file = "x\cba\addons\dummy.sqf";
			};
		};
	};
