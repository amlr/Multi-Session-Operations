#define COMPONENT ai
#include "script_mod.hpp"

#ifdef DEBUG_ENABLED_AI
	#define DEBUG_MODE_FULL
#endif

#ifdef DEBUG_SETTINGS_AI
	#define DEBUG_SETTINGS DEBUG_SETTINGS_AI
#endif

#include "script_macros.hpp"
