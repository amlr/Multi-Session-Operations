#define COMPONENT arrays
#include "script_mod.hpp"


#ifdef DEBUG_ENABLED_ARRAYS
	#define DEBUG_MODE_FULL
#endif

#ifdef DEBUG_SETTINGS_ARRAYS
	#define DEBUG_SETTINGS DEBUG_SETTINGS_ARRAYS
#endif

#include "script_macros.hpp"
